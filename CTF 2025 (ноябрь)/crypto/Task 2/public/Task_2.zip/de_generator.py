import pygame 
import sys 

from pygame.locals import *

class LCG:
    def __init__(self, seed):
        self.seed = seed
        self.__a = #a
        self.__b = #b
        self.__modulus = 8192

    def random_(self) -> int:
        self.seed = (self.__a * self.seed + self.__b) % self.__modulus
        return self.seed 

def GenerateRoomMap(room_seed: int) -> list:
    room_width = 7 + room_seed % 13
    room_length = 5 + room_seed % 11
    flame_walls_quantity = room_seed % ( room_width // 2)
    chest_quantity = room_seed % 3
    diamonds_quantity = room_seed % 8
    
    room_map = [[2] * (room_width + 2)] + [[2] + [0] * room_width  + [2] for _ in range(room_length)]   + [[2] + [3] +[2] * (room_width)] 
    for i in range(flame_walls_quantity): room_map[0][2 * i + 2] = 4
    for i in range(chest_quantity): room_map[i + 1][1] = 5
    for i in range(diamonds_quantity): room_map[room_length // 2 + i % 3][2 + i - i % 2 ] = 1
    


    room_map [chest_quantity + 1][1] = 6 if room_seed % 2 else 7
    return room_map

    
pygame.init()

RNG = LCG() #FECTF{****}
room_map = GenerateRoomMap(RNG.random_())
screen = pygame.display.set_mode((1024,600))
display = pygame.Surface((480,320))

floor_img = pygame.image.load('Assets\\Floor.png').convert()
floor_img.set_colorkey((0, 0, 0))

diamonds_img = pygame.image.load('Assets\\Diamonds.png').convert()
diamonds_img.set_colorkey((0, 0, 0))

wall_img = pygame.image.load('Assets\\Wall.png').convert()
wall_img.set_colorkey((0, 0, 0))

door_img = pygame.image.load('Assets\\Door.png').convert()
door_img.set_colorkey((0, 0, 0))

flame_wall_img = pygame.image.load('Assets\\Flame_Wall.png').convert()
flame_wall_img.set_colorkey((0, 0, 0))

chest_img = pygame.image.load('Assets\\Chest.png').convert()
chest_img.set_colorkey((0, 0, 0))

furnace_img = pygame.image.load('Assets\\Furnace.png').convert()
furnace_img.set_colorkey((0, 0, 0))

craft_table_img = pygame.image.load('Assets\\Crafting_table.png').convert()
craft_table_img.set_colorkey((0, 0, 0))

while True:
    display.fill((0,0,0))

    for y, row in enumerate(room_map):
        for x, tile in enumerate(row):

            display.blit(floor_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5))
            
            if tile == 1:
                display.blit(diamonds_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5))    

            if tile == 2:
                display.blit(wall_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5 - 14))      

            if tile == 3:
                display.blit(door_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5 - 14))
                 
            if tile == 4:
                 display.blit(flame_wall_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5 - 14))

            if tile == 5:
                 display.blit(chest_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5 - 14))

            if tile == 6:
                 display.blit(furnace_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5 - 14))    
            
            if tile == 7:
                 display.blit(craft_table_img, (250 + x * 10 - y * 10, 100 + x * 5 + y * 5 - 14))
        

            

    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                pygame.quit()
                sys.exit()

            if event.key == K_SPACE:
                room_map = GenerateRoomMap(RNG.random_())

                

    screen.blit(pygame.transform.scale(display, screen.get_size()), (0, 0))
    pygame.display.update()
